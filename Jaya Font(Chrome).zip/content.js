// Function to generate and inject all CSS directly into the website's DOM
function applyStyles(size) {
  // Pulling the font files safely from Dylan's official GitHub repository via jsDelivr CDN
  const fontUrlWoff2 = 'https://cdn.jsdelivr.net/gh/Dylan1216-Noob/Mau-Makan-Apa-Font-For-browsers-@main/JayaAbadiFont-Regular.woff2';
  const fontUrlWoff = 'https://cdn.jsdelivr.net/gh/Dylan1216-Noob/Mau-Makan-Apa-Font-For-browsers-@main/JayaAbadiFont-Regular.woff';
  
  let styleEl = document.getElementById('jaya-universal-font-style');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'jaya-universal-font-style';
    // Append it to documentElement (HTML) so it runs instantly at document_start
    document.documentElement.appendChild(styleEl);
  }
  
  // YouTube layout selectors to exclude so icons and players don't break
  const exclude = ':not([class*="ytp-"]):not(yt-icon):not(yt-icon *)';

  styleEl.textContent = `
    @font-face {
      font-family: 'CustomJayaFont';
      src: url('${fontUrlWoff2}') format('woff2'),
           url('${fontUrlWoff}') format('woff') !important;
      font-weight: normal;
      font-style: normal;
    }

    body, p, a, h1, h2, h3, h4, h5, h6, input, button, textarea, label, li, strong, em, b, td, th,
    div${exclude}, 
    span${exclude},
    i${exclude} {
      font-family: 'CustomJayaFont', sans-serif !important;
      font-size: ${size}px !important;
    }
  `;
}

// Fetch user size settings instantly when a new page begins loading
chrome.storage.sync.get('fontSize', (data) => {
  const currentSize = data.fontSize || 16; // Defaults to 16px if brand new
  applyStyles(currentSize);
});

// Real-time tracking listener: Updates page instantly when sliding the popup bar
chrome.runtime.onMessage.addListener((message) => {
  if (message.fontSize) {
    applyStyles(message.fontSize);
  }
});