const slider = document.getElementById('fontSizeSlider');
const display = document.getElementById('sizeValue');

chrome.storage.sync.get('fontSize', (data) => {
  if (data.fontSize) {
    slider.value = data.fontSize;
    display.textContent = data.fontSize;
  }
});

slider.addEventListener('input', () => {
  const size = slider.value;
  display.textContent = size;
  chrome.storage.sync.set({ fontSize: size });
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.id) {
      chrome.tabs.sendMessage(tabs[0].id, { fontSize: size });
    }
  });
});