const slider = document.getElementById('fontSizeSlider');
const display = document.getElementById('sizeValue');

chrome.storage.sync.get('fontSize', (data) => {
  if (data.fontSize) {
    slider.value = data.fontSize;
    display.textContent = data.fontSize;
  }
});

slider.addEventListener('input', () => {
  display.textContent = slider.value;
  chrome.storage.sync.set({ fontSize: slider.value });
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.id) {
      chrome.tabs.sendMessage(tabs[0].id, { fontSize: slider.value });
    }
  });
});
