function applyFontSize(size) {
  let styleEl = document.getElementById('jaya-font-size-style');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'jaya-font-size-style';
    document.documentElement.appendChild(styleEl);
  }
  
  // We added [class*="caption"] and [class*="ytp-"] to catch ALL YouTube player and subtitle elements, even in fullscreen!
  const exclude = ':not(html):not(body):not(ytd-app):not(#movie_player):not(#movie_player *):not([class*="caption"]):not([class*="ytp-"])';
  
  styleEl.textContent = `
    *${exclude}, 
    p${exclude}, 
    a${exclude}, 
    div${exclude}, 
    span${exclude}, 
    h1${exclude}, 
    h2${exclude}, 
    h3${exclude}, 
    h4${exclude}, 
    h5${exclude}, 
    h6${exclude}, 
    input${exclude}, 
    button${exclude}, 
    textarea${exclude}, 
    li${exclude} { 
      font-size: ${size}px !important; 
    }
  `;
}

chrome.storage.sync.get('fontSize', (data) => {
  if (data.fontSize) applyFontSize(data.fontSize);
});

chrome.runtime.onMessage.addListener((request) => {
  if (request.fontSize) applyFontSize(request.fontSize);
});